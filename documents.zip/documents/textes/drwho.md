# They're not aliens, they're Earth…liens!

Stop talking, brain thinking. Hush. All I've got to do is pass as an ordinary human being. Simple. What could possibly go wrong? I'm the Doctor, I'm worse than everyone's aunt. *catches himself* And that is not how I'm introducing myself.

Father Christmas. Santa Claus. Or as I've always known him: Jeff. It's a fez. I wear a fez now. __Fezes are cool.__ *Sorry, checking all the water in this area; there's an escaped fish.* You hit me with a cricket bat.

## You know how I sometimes have really brilliant ideas?

All I've got to do is pass as an ordinary human being. Simple. What could possibly go wrong? Annihilate? No. No violence. I won't stand for it. Not now, not ever, do you understand me?! I'm the Doctor, the Oncoming Storm - and you basically meant beat them in a football match, didn't you?

1. All I've got to do is pass as an ordinary human being. Simple. What could possibly go wrong?
2. You've swallowed a planet!
3. I am the Doctor, and you are the Daleks!

### It's a fez. I wear a fez now. Fezes are cool.

It's art! A statement on modern society, 'Oh Ain't Modern Society Awful?'! Annihilate? No. No violence. I won't stand for it. Not now, not ever, do you understand me?! I'm the Doctor, the Oncoming Storm - and you basically meant beat them in a football match, didn't you?

* *Insistently* Bow ties are cool! Come on Amy, I'm a normal bloke, tell me what normal blokes do!
* I am the Doctor, and you are the Daleks!
* I'm the Doctor, I'm worse than everyone's aunt. *catches himself* And that is not how I'm introducing myself.

The way I see it, every life is a pile of good things and bad things.…hey.…the good things don't always soften the bad things; but vice-versa the bad things don't necessarily spoil the good things and make them unimportant. Stop talking, brain thinking. Hush.

# Like a sloth. I can do that.

You all right, Dexter? I'm real proud of you for coming, bro. I know you hate funerals. You look…perfect. I'm not the monster he wants me to be. So I'm neither man nor beast. I'm something new entirely. With my own set of rules. I'm Dexter. Boo.

Somehow, I doubt that. You have a good heart, Dexter. You're a killer. I catch killers. I'm not the monster he wants me to be. So I'm neither man nor beast. I'm something new entirely. __With my own set of rules.__ *I'm Dexter.* Boo.
