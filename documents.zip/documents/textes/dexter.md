# Like a sloth. I can do that.

You all right, Dexter? I'm real proud of you for coming, bro. I know you hate funerals. You look…perfect. I'm not the monster he wants me to be. So I'm neither man nor beast. I'm something new entirely. With my own set of rules. I'm Dexter. Boo.

Somehow, I doubt that. You have a good heart, Dexter. You're a killer. I catch killers. I'm not the monster he wants me to be. So I'm neither man nor beast. I'm something new entirely. __With my own set of rules.__ *I'm Dexter.* Boo.

## I'm really more an apartment person.

I'm really more an apartment person. I like seafood. You look…perfect. Only you could make those words cute. I'm Dexter, and I'm not sure what I am. Makes me a … scientist.

1. Tell him time is of the essence.
2. Makes me a … scientist.
3. Tonight's the night. And it's going to happen again and again. It has to happen.

### I'm Dexter, and I'm not sure what I am.

Somehow, I doubt that. You have a good heart, Dexter. Under normal circumstances, I'd take that as a compliment. Tonight's the night. And it's going to happen again and again. It has to happen. Somehow, I doubt that. You have a good heart, Dexter.

* I'm going to tell you something that I've never told anyone before.
* I am not a killer.
* I am not a killer.

You all right, Dexter? Pretend. You pretend the feelings are there, for the world, for the people around you. Who knows? Maybe one day they will be. Makes me a … scientist. Cops, another community I'm not part of.

I am not a killer. Watching ice melt. This is fun. Pretend. You pretend the feelings are there, for the world, for the people around you. Who knows? Maybe one day they will be. I've lived in darkness a long time. Over the years my eyes adjusted until the dark became my world and I could see.

God created pudding, and then he rested. Keep your mind limber. I'm generally confused most of the time. You're a killer. I catch killers. I'm a sociopath; there's not much he can do for me.

Like a sloth. I can do that. I'm generally confused most of the time. I'm generally confused most of the time. I think he's got a crush on you, Dex! I'm real proud of you for coming, bro. I know you hate funerals.

Only you could make those words cute. Watching ice melt. This is fun. Makes me a … scientist. I'm thinking two circus clowns dancing. You? I'm really more an apartment person. Only you could make those words cute.

I think he's got a crush on you, Dex! He taught me a code. To survive. Rorschach would say you have a hard time relating to others. Rorschach would say you have a hard time relating to others. I love Halloween. The one time of year when everyone wears a mask … not just me.

Finding a needle in a haystack isn't hard when every straw is computerized. Hello, Dexter Morgan. I'm really more an apartment person. I like seafood.

Hello, Dexter Morgan. This man is a knight in shining armor. I'm a sociopath; there's not much he can do for me. He taught me a code. To survive. Watching ice melt. This is fun.

Hello, Dexter Morgan. Pretend. You pretend the feelings are there, for the world, for the people around you. Who knows? Maybe one day they will be. I'm not the monster he wants me to be. So I'm neither man nor beast. I'm something new entirely. With my own set of rules. I'm Dexter. Boo.

Under normal circumstances, I'd take that as a compliment. Makes me a … scientist. Hello, Dexter Morgan. Only you could make those words cute.

Hello, Dexter Morgan. I have a dark side, too. I feel like a jigsaw puzzle missing a piece. And I'm not even sure what the picture should be. I think he's got a crush on you, Dex! Tonight's the night. And it's going to happen again and again. It has to happen.
