# No. We're on the top.

Soothe us with sweet lies. You're going to do his laundry? Soon enough. Oh yeah, good luck with that. Really?! What's with you kids? Every other day it's food, food, food. Alright, I'll get you some stupid food.

Eeeee! Now say "nuclear wessels"! You know the worst thing about being a slave? __They make you work, but they don't pay you or let you go.__ *Bender, this is Fry's decision… and he made it wrong.* So it's time for us to interfere in his life.

## You're going to do his laundry?

Why not indeed! Five hours? Aw, man! Couldn't you just get me the death penalty? What are you hacking off? Is it my torso?! 'It is!' My precious torso! Oh, I think we should just stay friends. Why would a robot need to drink?

1. Ooh, name it after me!
2. Kids have names?
3. Bender, quit destroying the universe!

### And remember, don't do anything that affects anything, unless it turns out you were supposed to, in which case, for the love of God, don't not do it!

I am Singing Wind, Chief of the Martians. Perhaps, but perhaps your civilization is merely the sewer of an even greater society above you! That could be 'my' beautiful soul sitting naked on a couch. If I could just learn to play this stupid thing.

* I don't 'need' to drink. I can quit anytime I want!
* Oh right. I forgot about the battle.
* Come, Comrade Bender! We must take to the streets!

I never loved you. Leela, Bender, we're going grave robbing. Ooh, name it after me! I haven't felt much of anything since my guinea pig died.

Look, everyone wants to be like Germany, but do we really have the pure strength of 'will'? Oh, you're a dollar naughtier than most. You seem malnourished. Are you suffering from intestinal parasites? You won't have time for sleeping, soldier, not with all the bed making you'll be doing.
